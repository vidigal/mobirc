# mobirc
Projeto de criação de chat open source para estudo da linguagem Python

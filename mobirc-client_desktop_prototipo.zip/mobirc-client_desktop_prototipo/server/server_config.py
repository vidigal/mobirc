address = dict({
    'host': '192.168.1.5',
    'port': 38267
})

IDENTIFY_BUFFER = 64
RECEIVE_BUFFER = 512

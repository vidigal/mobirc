address = dict({
    'host': '192.168.1.5',
    'port': 38267
})

MESSAGE_BUFFER = 1024
